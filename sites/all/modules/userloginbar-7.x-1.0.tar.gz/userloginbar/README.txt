*******************************************************
  README.txt for Userlogin.module for Drupal
*******************************************************

Userloginbar is a module written by developers at Ebizon Technologies (www.ebizontek.com). It is the implementation of http://drupal.org/node/92657#comment-792952. This module creates a new user login bar block. This means this shows up username, password, submit button block in a single line that is so often the requirement in the new genx websites.


Important:
------------
1) This also means you need to replace your old userlogin block with the new "User login bar" block. 

2) You might need to "Clear Cache" from admin/config/development/performance, if the new user login block does not show up in admin/structure/block.

Special Thanks:
================
Alan Jacobson of Brass Tacks Design (http://www.brasstacksdesign.com) for sponsering the work.

Author:
========
Sudeep Goyal from Ebizon Technologies 
(http://www.ebizontek.com)
