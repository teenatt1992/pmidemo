<?php
/**
  * @file
  * folder_breadcrumb_link.tpl.php
  */
?>  

<span style="padding-left:<?php print $padding_left ?>px;">
    <a href="#" onClick="YAHOO.filedepot.showfiles(<?php print $catid ?>);return false;"><?php print $folder_name ?></a><span style="font-size:11pt;font-weight:bold;padding-left:3px; color:#666;">&gt;</span>
</span>