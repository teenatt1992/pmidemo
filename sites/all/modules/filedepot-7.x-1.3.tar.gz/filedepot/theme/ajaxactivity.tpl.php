<?php
/**
  * @file
  * ajaxactivity.tpl.php
  */
?>

<div id="filedepot_ajaxActivity" class="floatright" style="padding-right:5px;padding-top:3px;padding-bottom:5px;visibility:hidden;"><img src="<?php print $layout_url ?>/css/images/activity.gif"></div>
