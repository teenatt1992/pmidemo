
README.txt - Drupal Module - Messaging 7
========================================

Drupal Messaging Framework

This is a messaging framework to allow message sending in a channel independent way
It will provide a common API for sending while allowing plugins for multiple channels

This Messaging Framework has been primarily developed to be used by the Notifications Framework.
See Drupal notifications module for an usage usage example implementing the full messaging capabilities.

Online documentation, includes end user and development handbooks: http://drupal.org/node/252582

Note: some of the plug-ins depend on other packages and may not be available yet for Drupal 6

Developers:
-----------
- Tim Cullen
- Jeff Miccolis
- Jose A. Reyero

Development Seed, http://www.developmentseed.org