Drupal 7 version of the taxonomy_block module (http://drupal.org/project/taxonomy_block).


Settings
----------------------------
http://www.domian.de/admin/config/user-interface/taxonomy_block

Chose Vocabulary, and then go to admin/structure/block and assign the block to a region.
